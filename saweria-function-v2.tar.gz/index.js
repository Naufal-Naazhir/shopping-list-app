const sdk = require("node-appwrite");

/*
  Pastikan Environment Variables sudah di-set di Dashboard Appwrite Function:
  1. APPWRITE_ENDPOINT (misal: https://cloud.appwrite.io/v1)
  2. APPWRITE_PROJECT_ID
  3. APPWRITE_API_KEY (Buat API Key dengan scope: documents.read & documents.write)
  4. APPWRITE_DATABASE_ID (ID Database utama Anda)
*/

module.exports = async function ({ req, res, log, error }) {
  log('Request Object:', req); // <-- Debugging line added
  const client = new sdk.Client();
  const databases = new sdk.Databases(client);

  // Inisialisasi Client
  if (
    !process.env.APPWRITE_ENDPOINT ||
    !process.env.APPWRITE_PROJECT_ID ||
    !process.env.APPWRITE_API_KEY ||
    !process.env.APPWRITE_DATABASE_ID
  ) {
    error("Environment variables belum lengkap! Pastikan APPWRITE_ENDPOINT, APPWRITE_PROJECT_ID, APPWRITE_API_KEY, dan APPWRITE_DATABASE_ID sudah di-set.");
    return res.json({ status: "error", message: "Server misconfiguration" }, 500);
  }

  client
    .setEndpoint(process.env.APPWRITE_ENDPOINT)
    .setProject(process.env.APPWRITE_PROJECT_ID)
    .setKey(process.env.APPWRITE_API_KEY);

  // 1. Cek Method & Parsing Data
  if (req.method !== "POST") {
    return res.send("Method not allowed. Use POST.", 405);
  }

  try {
    // Saweria mengirim body dalam bentuk JSON text, perlu di-parse
    // Jika req.body sudah object, hapus JSON.parse
    const payload = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    
    log("Data masuk dari Saweria:", payload);

    // 2. Validasi Nominal & Tipe Donasi
    // Sesuaikan minimal donasi (30000)
    if (payload.amount_raw < 30000) {
       return res.json({ status: "ignored", message: "Nominal kurang" });
    }

    // Ambil email pembayar dari Saweria
    const donorEmail = payload.message.trim(); 

    if (!donorEmail) {
        return res.json({ status: "failed", message: "Email tidak ditemukan di payload" });
    }

    // 3. Cari User di Database Appwrite berdasarkan Email
    const userDocs = await databases.listDocuments(
      process.env.APPWRITE_DATABASE_ID, 
      'users',
      [
        sdk.Query.equal('email', donorEmail) // Pastikan ada kolom 'email' di collection users
      ]
    );

    if (userDocs.total === 0) {
        error(`User dengan email ${donorEmail} tidak ditemukan di database.`);
        return res.json({ status: "failed", message: "User not found" });
    }

    const userId = userDocs.documents[0].$id;

    // 4. Update Status Premium
    await databases.updateDocument(
      process.env.APPWRITE_DATABASE_ID,
      'users',
      userId,
      {
        isPremium: true, // Pastikan kolom ini tipe Boolean
        // premium_until: ... (opsional jika ada tanggal expired)
      }
    );

    log(`Sukses upgrade premium untuk: ${donorEmail}`);
    return res.json({ status: "success", message: "User upgraded to Premium" });

  } catch (err) {
    error("Terjadi Error: " + err.message);
    return res.json({ status: "error", message: err.message }, 500);
  }
};